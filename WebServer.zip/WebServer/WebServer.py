import http.server
import socketserver
import ssl
import os

PORT = 443
DIRECTORY = "C:\\Users\\Windows-PC\\Desktop\\WebServer\\Files"

os.chdir(DIRECTORY)

Handler = http.server.SimpleHTTPRequestHandler

httpd = socketserver.TCPServer(("", PORT), Handler)

# Create an SSL context
context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain(certfile="C:\\Certbot\\live\\v31574.1blu.de\\fullchain.pem", keyfile="C:\\Certbot\\live\\v31574.1blu.de\\privkey.pem")

# Wrap the server's socket with the SSL context
httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

print(f"Serving HTTPS on port {PORT}")
httpd.serve_forever()