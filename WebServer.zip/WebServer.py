import http.server
import socketserver
import ssl
import os

PORT = 8443
DIRECTORY = "C:\\Users\\WindowsPC\\Desktop\\WebServer\\Files"

os.chdir(DIRECTORY)

Handler = http.server.SimpleHTTPRequestHandler

httpd = socketserver.TCPServer(("", PORT), Handler)

# Create an SSL context
context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain(certfile="C:\\Certbot\\live\\updateark.duckdns.org\\fullchain.pem", keyfile="C:\\Certbot\\live\\updateark.duckdns.org\\privkey.pem")

# Wrap the server's socket with the SSL context
httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

print(f"Serving HTTPS on port {PORT}")
httpd.serve_forever()