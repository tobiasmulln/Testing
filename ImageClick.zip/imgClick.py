import subprocess
import sys

REQUIRED_PACKAGES = ["python_imagesearch", "pyautogui", "keyboard"]

for package in REQUIRED_PACKAGES:
    try:
        __import__(package)  # Try to import the package
        print(f"{package} is installed")
    except ImportError:
        print(f"{package} is NOT installed. Installing...")
        subprocess.call([sys.executable, "-m", "pip", "install", package])

from python_imagesearch import imagesearch
import pyautogui
import time

def find_and_click(image_path, x_offset=0, y_offset=0):
    pos = imagesearch.imagesearch(image_path)
    if pos[0] != -1:
        print(f"{image_path} found at {pos}. Clicking...")
        pyautogui.moveTo(pos[0] + x_offset, pos[1] + y_offset)
        pyautogui.click(pos[0] + x_offset, pos[1] + y_offset)  # Click 

def click_image(images, error_images, click_after_error_image, x_offset=0, y_offset=0):
    """
    Search for the images on the screen and click on one if found.
    If an error image is found, more complex operations will be performed.
    """
    while True:
        for image_path in images:
            find_and_click(image_path, x_offset, y_offset)
        
        for error_image_path in error_images:
            pos = imagesearch.imagesearch(error_image_path)
            if pos[0] != -1:
                print(f"Error image {error_image_path} found at {pos}. Performing error routine...")
                pyautogui.press("f5")  # Press F5
                time.sleep(2)
                pyautogui.press("enter")  # Press Enter
                pyautogui.moveTo(960, 540)  # Move mouse to center of the screen (for a 1920x1080 resolution)
                time.sleep(5)  # Wait for 8 seconds
                pyautogui.click()  # Click once

                # Look for 'speedtestclick.bmp'
                for click_image_path in click_after_error_image:
                    find_and_click(click_image_path, x_offset, y_offset)
                    time.sleep(2)  # Wait for 2 seconds
                    pyautogui.click()  # Click again

                break  # Exit loop if error image is found and clicked        

        else:
            print("Images not found.")
            time.sleep(5)  # Resting 5 seconds before the next search

click_image(
    ["C:\\Users\\Windows-PC\\Desktop\\image.bmp", "C:\\Users\\Windows-PC\\Desktop\\image2.bmp"], 
    ["C:\\Users\\Windows-PC\\Desktop\\error.bmp"], 
    ["C:\\Users\\Windows-PC\\Desktop\\speedtestclick.bmp"],
    x_offset=30, y_offset=30
)