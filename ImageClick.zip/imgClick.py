import subprocess
import sys

REQUIRED_PACKAGES = ["python_imagesearch", "pyautogui", "keyboard"]

for package in REQUIRED_PACKAGES:
    try:
        __import__(package)  # Try to import the package
        print(f"{package} is installed")
    except ImportError:
        print(f"{package} is NOT installed. Installing...")
        subprocess.call([sys.executable, "-m", "pip", "install", package])

from python_imagesearch import imagesearch
import pyautogui
import time

def click_image(images, x_offset=0, y_offset=0):
    """
    Search for the images on the screen and click on the first one found.
    Then move the mouse pointer away after 2 seconds.
    """
    while True:
        for image_path in images:
            pos = imagesearch.imagesearch(image_path)

            if pos[0] != -1:
                print(f"{image_path} found at {pos}. Clicking...")
                pyautogui.moveTo(pos[0] + x_offset, pos[1] + y_offset)
                pyautogui.click(pos[0] + x_offset, pos[1] + y_offset)  # First click
                time.sleep(3)  # Wait for 3 seconds
                pyautogui.click(pos[0] + x_offset, pos[1] + y_offset)  # Second click
                time.sleep(2)  # Wait for 2 seconds
                print(f"Move mouse away from {image_path}")
                pyautogui.moveTo(0 + 10, 0 + 10)
                break  # Exit loop if image is found and clicked
        else:
            print("Images not found.")
            time.sleep(5)  # Resting 1 second before the next search

# Provide full paths to the images
click_image(["C:\\Users\\Windows-PC\\Desktop\\image.bmp", "C:\\Users\\Windows-PC\\Desktop\\image2.bmp"], x_offset=30, y_offset=30)