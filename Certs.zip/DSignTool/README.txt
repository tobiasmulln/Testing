Tutorial: https://www.unknowncheats.me/forum/anti-cheat-bypass/587763-sign-kernel-driver-leaked-certificate.html

Netgear Password: N3tg3aR!
