import ctypes
import subprocess
import sys

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, __file__, None, 1)
    sys.exit()

REQUIRED_PACKAGES = ["python_imagesearch", "pyautogui", "keyboard", "Pillow", "pyscreeze"]

for package in REQUIRED_PACKAGES:
    try:
        __import__(package)  # Try to import the package
        print(f"{package} is installed")
    except ImportError:
        print(f"{package} is NOT installed. Installing...")
        subprocess.call([sys.executable, "-m", "pip", "install", package])

import os
import time
from python_imagesearch import imagesearch
import pyautogui

def find_and_click(image_path, x_offset=0, y_offset=0):
    pos = imagesearch.imagesearch(image_path)  
    if pos[0] != -1:
        print(f"{image_path} found at {pos}. Clicking...")
        pyautogui.moveTo(pos[0] + x_offset, pos[1] + y_offset)
        pyautogui.click(pos[0] + x_offset, pos[1] + y_offset)
        time.sleep(2)
        pyautogui.click(pos[0] + x_offset, pos[1] + y_offset)

def capture_screenshot(base_path):
    idx = 0
    while os.path.exists(f"{base_path}_{idx}.png"):
        idx += 1
    output_path = f"{base_path}_{idx}.png"
    pyautogui.screenshot(output_path)
    print(f"Screenshot saved to {output_path}")

def click_image(images, error_images, click_after_error_image, x_offset=0, y_offset=0):
    while True:
        try:  # Start of try block
            for image_path in images:
                find_and_click(image_path, x_offset, y_offset)

            pos = imagesearch.imagesearch("C:\\Users\\Windows-PC\\Desktop\\error.bmp")
            if pos[0] != -1:
                print(f"Error image {image_path} found at {pos}. Performing error routine...")
                capture_screenshot("C:\\Users\\Windows-PC\\Desktop\\errorscreenshots\\error_screenshot")

                pyautogui.press("f5")
                time.sleep(2)
                pyautogui.press("enter")
                pyautogui.moveTo(960, 540)
                time.sleep(8)
                pyautogui.click()

                for click_image_path in click_after_error_image:
                    find_and_click(click_image_path, x_offset, y_offset)
                    time.sleep(2)
                    pyautogui.click()

            else:
                print("Images not found.")
                time.sleep(5)
        except Exception as e:  # If any error occurs
            print(f"An error occurred: {e}")
            continue  # Skip to the next loop iteration

click_image(
    ["C:\\Users\\Windows-PC\\Desktop\\image.bmp", "C:\\Users\\Windows-PC\\Desktop\\image2.bmp", "C:\\Users\\Windows-PC\\Desktop\\speedtestclick.bmp"], 
    ["C:\\Users\\Windows-PC\\Desktop\\error.bmp", "C:\\Users\\Windows-PC\\Desktop\\blackscreen.bmp"], 
    ["C:\\Users\\Windows-PC\\Desktop\\speedtestclick.bmp"],
    x_offset = 30, 
    y_offset = 30
)