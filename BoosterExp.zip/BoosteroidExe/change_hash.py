import os
import random
import hashlib

filename = "korean.exe"

# Check if the provided file exists
if not os.path.exists(filename):
    print("Error: File not found")
    exit(1)

# Get the original hash of the file
with open(filename, "rb") as f:
    file_data = f.read()
    original_hash = hashlib.sha256(file_data).hexdigest()

print(f"Original hash: {original_hash}")

# Append a random byte to the file to change its hash
with open(filename, "ab") as f:
    f.write(os.urandom(1))

# Get the updated hash of the file
with open(filename, "rb") as f:
    file_data = f.read()
    updated_hash = hashlib.sha256(file_data).hexdigest()

print(f"Updated hash: {updated_hash}")