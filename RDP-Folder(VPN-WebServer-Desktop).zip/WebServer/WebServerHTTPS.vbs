Set WshShell = CreateObject("WScript.Shell")

Function QuoteString(str)
    QuoteString = Chr(34) & str & Chr(34)
End Function

If Not WScript.Arguments.Named.Exists("elevate") Then
    Set objShell = CreateObject("Shell.Application")
    objShell.ShellExecute "wscript.exe", QuoteString(WScript.ScriptFullName) & " /elevate", , "runas", 1
    WScript.Quit
End If

pythonPath = "python"
scriptPath = "C:\Users\WindowsPC\Desktop\WebServer\WebServer.py"
command = pythonPath & " " & QuoteString(scriptPath)

Do
    If IsWebServerRunning() Then
        TerminateWebServer
    End If

    WshShell.Run command, 0, False
    WScript.Sleep 3600000
Loop

Function IsWebServerRunning()
    Dim objWMIService, colProcesses, objProcess
    Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")
    Set colProcesses = objWMIService.ExecQuery("Select * from Win32_Process Where Name = 'python.exe'")
    For Each objProcess In colProcesses
        If InStr(objProcess.CommandLine, "WebServer.py") > 0 Then
            IsWebServerRunning = True
            Exit Function
        End If
    Next
    IsWebServerRunning = False
End Function

Sub TerminateWebServer()
    Dim objWMIService, colProcesses, objProcess
    Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")
    Set colProcesses = objWMIService.ExecQuery("Select * from Win32_Process Where Name = 'python.exe'")
    For Each objProcess In colProcesses
        If InStr(objProcess.CommandLine, "WebServer.py") > 0 Then
            objProcess.Terminate()
        End If
    Next
End Sub