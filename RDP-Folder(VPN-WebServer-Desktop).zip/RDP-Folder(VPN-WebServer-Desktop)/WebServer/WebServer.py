import http.server
import socketserver
import ssl
import os
import time
from threading import Thread
import subprocess

# ------------------------------
# Configuration
# ------------------------------
PORT = 443
DIRECTORY = r"C:\Users\WindowsPC\Desktop\WebServer\Files"
CERT_PATH = r"C:\Certbot\live\markuslanger.germanywestcentral.cloudapp.azure.com\fullchain.pem"
KEY_PATH = r"C:\Certbot\live\markuslanger.germanywestcentral.cloudapp.azure.com\privkey.pem"
RENEW_INTERVAL = 2592000  # seconds, for testing. Use 2592000 for 30 days in production
CERTBOT_PATH = r"C:\Program Files\Certbot\bin\certbot.exe"

# ------------------------------
# Change working directory
# ------------------------------
os.chdir(DIRECTORY)

# ------------------------------
# HTTP Handler
# ------------------------------
Handler = http.server.SimpleHTTPRequestHandler
httpd = socketserver.TCPServer(("", PORT), Handler)

# ------------------------------
# Create SSL context
# ------------------------------
def create_ssl_context():
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=CERT_PATH, keyfile=KEY_PATH)
    return context

# Wrap server socket with initial SSL
context = create_ssl_context()
httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

# ------------------------------
# Background thread to renew certificate
# ------------------------------
def cert_renew_thread():
    global httpd, context
    while True:
        time.sleep(RENEW_INTERVAL)
        try:
            print(f"[{time.strftime('%X')}] Running Certbot to renew certificate...")
            # Use 'renew' to overwrite existing certificate files
            subprocess.run([
                CERTBOT_PATH,
                "renew",
                "--quiet"  # suppress output unless there is an error
            ], check=True)
            
            # Reload SSL context after renewal
            print(f"[{time.strftime('%X')}] Reloading renewed certificate...")
            context = create_ssl_context()
            httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
            print(f"[{time.strftime('%X')}] Certificate reloaded successfully.")
        except subprocess.CalledProcessError as e:
            print(f"[{time.strftime('%X')}] Error renewing certificate: {e}")

# Start background thread
Thread(target=cert_renew_thread, daemon=True).start()

# ------------------------------
# Start HTTPS server
# ------------------------------
print(f"Serving HTTPS on port {PORT}")
httpd.serve_forever()