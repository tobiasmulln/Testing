echo https://localhost:47990 | clip
