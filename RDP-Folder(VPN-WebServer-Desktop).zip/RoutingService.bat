@echo off

:: Check for administrative privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell "Start-Process '%0' -Verb runAs"
    exit /b
)

:: Function to check and set the service start type to manual
:CheckAndSetStartType
sc qc RemoteAccess | findstr /I "START_TYPE"
if %errorlevel% neq 0 (
    echo Failed to query the service start type.
    exit /b
)

:: Check if the start type is manual
for /f "tokens=2 delims=:" %%A in ('sc qc RemoteAccess ^| findstr /I "START_TYPE"') do (
    set "startType=%%A"
)
setlocal enabledelayedexpansion
set "startType=!startType: =!"  :: Remove leading spaces

if /I "!startType!" neq "Manual" (
    echo Changing the start type of RemoteAccess to Manual...
    sc config RemoteAccess start= demand
) else (
    echo The start type of RemoteAccess is already set to Manual.
)

:: Check the status of the RemoteAccess service
sc query RemoteAccess | findstr /I "RUNNING"
if %errorlevel% == 0 (
    echo RemoteAccess is currently running. Stopping the service...
    sc stop RemoteAccess
    :: Wait for a moment to ensure the service has stopped
    timeout 1
) else (
    echo RemoteAccess is currently stopped. Starting the service...
    sc start RemoteAccess
)

:: Display the current status of the service
sc query RemoteAccess | findstr /I "STATE"

echo Done.